<?php
define("HOST", "ec2-54-246-98-119.eu-west-1.compute.amazonaws.com");
define("DATABASE", "d4f2uther4d3uk");
define("USER", "gurfrjwmuedfot");
define("PORT", "5432");
define("PASSWORD", "06e304a9e8b6c7b590df483952c65689eb12d16e4ea7443c44c688b8496f0639");
?>